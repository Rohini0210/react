import LandingDetails from './landingDetails';
import LandingDisplay from './landingDisplay';
import LandingTitle from './landingTitle';

export { LandingTitle, LandingDisplay, LandingDetails };
