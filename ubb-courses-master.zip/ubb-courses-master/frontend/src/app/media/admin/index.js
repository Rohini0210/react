import MediaAdminList from './mediaAdminList';

export { MediaAdminList };
