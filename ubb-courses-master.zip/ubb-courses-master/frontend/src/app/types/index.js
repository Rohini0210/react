import AppRoutes from './appRoutes';
import AuthorityTypes from './authority';

export { AppRoutes, AuthorityTypes };
