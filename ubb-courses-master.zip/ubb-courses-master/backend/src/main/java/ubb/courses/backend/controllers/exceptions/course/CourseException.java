package ubb.courses.backend.controllers.exceptions.course;

public class CourseException extends RuntimeException {
    public CourseException(String message) {super(message);}
}
