package ubb.courses.backend.models.lesson;

public enum LessonType {
    TEXT,
    IMAGE,
    VIDEO,
    DOWNLOADABLE
}
