package ubb.courses.backend.dtos;

public abstract class DTO {
}
