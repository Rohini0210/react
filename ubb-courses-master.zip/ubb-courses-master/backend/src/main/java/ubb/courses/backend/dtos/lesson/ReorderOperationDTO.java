package ubb.courses.backend.dtos.lesson;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ReorderOperationDTO {
    private Integer order;
}
