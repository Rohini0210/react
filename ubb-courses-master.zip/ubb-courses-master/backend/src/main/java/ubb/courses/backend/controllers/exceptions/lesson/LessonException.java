package ubb.courses.backend.controllers.exceptions.lesson;

public class LessonException extends RuntimeException {
    public LessonException(String message) {super(message);}
}
