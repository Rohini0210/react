package ubb.courses.backend.models.authorization;

public enum AuthorityType {
    ADMIN,
    TEACHER,
    STUDENT
}
